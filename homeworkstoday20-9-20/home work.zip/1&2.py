# Taking a function called sum
def sum(num1 , num2):
    result = num1 + num2
    return result

# Invoking the functions
sum_result = sum(9,8)
print(sum_result)




def first_function_with_params(greeting1, greeting2):
    print(greeting1 + " " + greeting2)

#invoking the function
first_function_with_params("Rushi", " Datta")

