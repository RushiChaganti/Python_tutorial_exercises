#declaring a list of capital cities
capital_cities = ["Abudhabi" , "Beijing" , "London" , "Kuwait city" , "Tokyo" , "Geneva" ]
print(capital_cities )
capital_cities.remove("Geneva")
print(capital_cities)


