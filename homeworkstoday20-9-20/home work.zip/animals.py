Favourite_animals = ["Dog","Cat","Macaw"]
for animal in Favourite_animals:
    print(animal)

for  animal in Favourite_animals:
    print(f"{animal} is a great pet")


print("Dog  would make a great pet!")   
print("Cat  would make a great pet!")  
print("Macaw  would make a great pet!")     


