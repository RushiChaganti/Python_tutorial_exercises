#declaring a list of five places which i want to travel 
places_visit = ["Ladakh", "Rameshwaram" , "kasi" , "Tirupati" , "Arunachalam"]
print(places_visit)
beta_sort = sorted(places_visit)
print(beta_sort)
print("original list")
print(places_visit)
reverse_sort = sorted(places_visit)
print(reverse_sort)
print("original list")
print(places_visit)
print("Reversing the order of the list")
places_visit.reverse()
print(places_visit)
print("Reversing the order of the list again")
places_visit.reverse()
print(places_visit)
print("sorting the list in alphabetical order")
places_visit.sort()
print(places_visit)
places_visit.sort(reverse=True)
print(places_visit)



