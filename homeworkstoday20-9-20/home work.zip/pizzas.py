Favourite_pizzas = ["Tomato","Cheese","pepperoni"]
for pizza in Favourite_pizzas:
    print(pizza)

for pizza in Favourite_pizzas:   
    print(f"I like {pizza} pizza")

print("I love pizzas")
print("pizzas are very tasty")
print("pizzas are great")